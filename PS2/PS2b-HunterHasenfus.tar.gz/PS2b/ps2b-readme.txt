/**********************************************************************
 *                                                  
 *  PS2b: Sokoban
 **********************************************************************/

Name: Hunter M Hasenfus

Hours to complete assignment : 2

/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.
 **********************************************************************/

Yes, I completed the whole assignment. 

/**********************************************************************
 *  Did you attempt the extra credit parts? Which one(s)?
 *  Successfully or not?  
 **********************************************************************/

I made the character change images when moving, I made the boxes light up when they were placed on the storage locations, and 
I made the player turn into a you win image when they won. 

Image can be found at: https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.123rf.com%2Fclipart-vector%2Fyou_win.html&psig=AOvVaw37GjGCdWVexwXnf_2BbYVa&ust=1677632990384000&source=images&cd=vfe&ved=0CBEQ3YkBahcKEwjgmdGGhLf9AhUAAAAAHQAAAAAQBA


/**********************************************************************
 *  Did your code pass cpplint?
 *  Indicate yes or no, and explain how you did it.
 **********************************************************************/

No, do I have to fix all of teh white space end of line stuff? Seems like a hassle that just isnt worth my time.
/**********************************************************************
 *  List whatever help (if any) you received from TAs,
 *  classmates, or anyone else.
 **********************************************************************/

N/A

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
N/A

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
N/A