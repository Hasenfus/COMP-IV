PSX on PS2a

Hunter Hasenfus

I found that the majority of the errors were about the formatting as in the new lines and certain spaces. 
I went through the three files: main.cpp, Sokaban.cpp, and Sokaban.h as fixed all of those. 
Lastly I changed the using namespace to the using-declarations, and then applied my own fake Copyright. 

After that all the errors were gone. 